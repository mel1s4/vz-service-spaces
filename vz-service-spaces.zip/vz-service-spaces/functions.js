
function vz_ss_validate_uid() { 
  const input = document.getElementById("vz_ss_space_uid_input");
  const container = document.getElementById("vz_ss_uid");
  // example: ASD3-AS3D-ASD3
  input.value = input.value.replace("-", '').toUpperCase();
  if (input.value.length >= 12) {
    input.value = input.value.slice(0, 12); 
  }
  let nCode = input.value.replace(/(.{4})/g, '$1-').trim();
  // if las char is - remove it
  if (nCode.charAt(nCode.length - 1) === '-') {
    nCode = nCode.slice(0, -1);
  }
  container.innerHTML = nCode;
}

document.getElementById("vz_ss_space_uid_input").addEventListener("input", vz_ss_validate_uid);