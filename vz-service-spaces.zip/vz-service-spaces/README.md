<img width="387" alt="image" src="https://github.com/user-attachments/assets/9f5f60e2-1ac3-493a-b103-b61570acb34b" />

# Viroz Service Spaces

This plugin adds a custom post type called "Service Space" that can generate codes to be able to visit the site with it and make orders assigned directly to this service space.

The service scope is 6 hours but can be removed manually.

When a users places an order the meta data about the service space will be saved into the order and, if the code is still active, it will apear in the current orders of the service space.

